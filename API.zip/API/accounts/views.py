from rest_framework.response import Response
from .serializers import  RegisterSerializer,LoginSerializer,ReterieveSerializer
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.generics import ListAPIView,RetrieveAPIView
from accounts.models import User
from rest_framework_jwt.settings import api_settings
from django.shortcuts import render
JWT_DECODE_HANDLER = api_settings.JWT_DECODE_HANDLER
import base64
# Register API
class Register(APIView):

    def post(self, request):
        data = request.data
        serializer = RegisterSerializer(data=data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            response = {'success' : 'True','status code' : status.HTTP_201_CREATED,'message': 'User registered  successfully'}
            return Response(response)
        else:
            return Response(serializer.errors, status=HTTP_200_BAD_REQUEST)

#Login API
class UserLoginView(RetrieveAPIView):
    def post(self, request):
        data = request.data

        serializer = LoginSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        response = {'success' : 'True','status code' : status.HTTP_200_OK,'message': 'User logged in  successfully','token' : serializer.data['token']}
        return Response(response)

#UserProfileView
class UserProfileView(RetrieveAPIView):
    #serializer_class = ProfileSerializer
    def get(self,request):
       data = request.data
       access_token = data.get("token", None)
       if not access_token:
           return Response( status=HTTP_200_BAD_REQUEST)
       else:
           decoded_data = JWT_DECODE_HANDLER(access_token)
           id       = decoded_data.get("user_id",None)
           username = decoded_data.get("username",None)
           email    = decoded_data.get("email", None)
           return Response({'success':True,'status code' : status.HTTP_200_OK})

class DashboardView(ListAPIView):
    serializer_class = ReterieveSerializer
    queryset = User.objects.all()

# Dashboard API
class Dashboard(APIView):
    def get(self,request):
        renderer = getattr(self, 'accepted_renderer', None)
        data = request.headers
        get_token = request.headers.get('Authorization',None)
        token = str.replace(get_token,'Bearer ', '')      #remove bearer from token
        if not token:
            return Response(status=HTTP_200_BAD_REQUEST)
        else:
            decoded_data = JWT_DECODE_HANDLER(token)
            id = decoded_data.get("user_id", None)
            username = decoded_data.get("username", None)
            email = decoded_data.get("email", None)
            return Response({'success':True,'status code': status.HTTP_200_OK,'id':id,'username':username,'email':email})






from rest_framework import serializers
from accounts.models import User
from rest_framework_jwt.settings import api_settings
import requests
JWT_PAYLOAD_HANDLER = api_settings.JWT_PAYLOAD_HANDLER
JWT_ENCODE_HANDLER = api_settings.JWT_ENCODE_HANDLER
JWT_DECODE_HANDLER = api_settings.JWT_DECODE_HANDLER

# Register Serializer
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'email', 'password')
    #Register new user
    def create(self, validated_data):
        username = validated_data['username']
        email = validated_data['email']
        password = (validated_data['password'])
        user = User(username=username,email=email,password=password)
        if user.isemailexist():
            raise serializers.ValidationError(' Email already exist.')
        elif user.isuserexist():
            raise serializers.ValidationError(' Username already exist.')
        else:
            user.save()
            return user

# Login Serializer
class LoginSerializer(serializers.ModelSerializer):
    username = serializers.CharField(max_length=30)
    password = serializers.CharField(max_length=128, write_only=True)
    token = serializers.CharField(allow_blank=True,read_only=True)
    def validate(self, data):
        username = data.get("username", None)
        password = data.get("password", None)
        user = User.get_user_by_username(username=username)
        if user:
            if password == user.password:
                    payload = JWT_PAYLOAD_HANDLER(user)
                    jwt_token = JWT_ENCODE_HANDLER(payload)
            else:
                    serializers.ValidationError('User with given username and password does not exists' )
        else:
            serializers.ValidationError(' username and password is not found.')

        return {'username': user.username, 'token':jwt_token}

    class Meta:
        model = User
        fields = ('username','password','token')

#Reterieve Serializer
class ReterieveSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields=['id','username','email','password']


'''class ProfileSerializer(serializers.ModelSerializer):

    def validate(self,data):
        data = data.get('token',None)
        print(data)


        if not access_token:
            serializers.ValidationError("Token is expire")
        else:
            decoded_data = JWT_DECODE_HANDLER(access_token)
            id = decoded_data.get("user_id", None)
            username = decoded_data.get("username", None)
            email = decoded_data.get("email", None)
            return {'id':id,'username':username,'email':email}

    class Meta:
        model = User
        fields = ['id','username','email']
'''
class DashboardSerializer(serializers.ModelSerializer):
    def validate(self,data):
        data = data.headers
        print(data)



from accounts import views
from django.urls import path,include
from .views import Register,UserLoginView,DashboardView,UserProfileView,Dashboard
urlpatterns = [

    path('register', Register.as_view(), name='register'),
    path('login',UserLoginView.as_view(),name='login'),
    path('dashboard',DashboardView.as_view(),name='dashboard'),
    path('profileview',UserProfileView.as_view(),name='profileview'),
    path('dashboardviews',Dashboard.as_view())

]



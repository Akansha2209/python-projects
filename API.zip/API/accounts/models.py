from django.db import models

class User(models.Model):
    id       = models.IntegerField(primary_key=True)
    username = models.CharField(max_length=30)
    email = models.EmailField(max_length=60)
    password = models.CharField(max_length=60)

# find username from the database

    def get_user_by_username(username):
        try:
            return User.objects.get(username=username)
        except:
            return False

# check email address is already Exist.
    def isemailexist(self):
        if User.objects.filter(email=self.email) :
            return True
        else:
            return False

# check user name is already Exist.
    def isuserexist(self):
        if User.objects.filter(username=self.username):
            return True
        else:
            return False